<#
.SYNOPSIS
    DelgadoLogic AR-Series Lite Triage v5.5 - Free Diagnostic Tool
.DESCRIPTION
    Lite edition: scans for Moment 5 audio conflicts and generates
    a Diagnostic ID. Full remediation requires the Enterprise Suite.
.NOTES
    Author: Manuel Alejandro Delgado | DelgadoLogic.tech
    Identity: DelgadoLogic (Billing ID: DELGADOLOGI)
    Version: 5.5 Lite
    License: MIT | Delgado Creative Enterprises LLC
    Support: support@delgadologic.tech
    Website: https://delgadologic.tech
    GitHub:  Chronolapse411
#>
$ErrorActionPreference = "Stop"
$DiagID = "DL-LITE-$(Get-Random -Minimum 10000 -Maximum 99999)"
Clear-Host
Write-Host "###############################################################" -ForegroundColor Cyan
Write-Host "#      DELGADOLOGIC AR-SERIES ARCHITECT (v5.5 Lite)        #" -ForegroundColor Cyan
Write-Host "#      Lead Systems Engineer: Manuel Alejandro Delgado        #" -ForegroundColor Cyan
Write-Host "#      Diagnostic ID: $($DiagID.PadRight(32)) #" -ForegroundColor Cyan
Write-Host "###############################################################" -ForegroundColor Cyan
Write-Host ""
if (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "[!] CRITICAL: Run as Administrator." -ForegroundColor Red; Pause; Exit
}

Write-Host "===============================================================" -ForegroundColor DarkYellow
Write-Host "  DISCLAIMER: This utility is intended for IT professionals"    -ForegroundColor Yellow
Write-Host "  and advanced users. DelgadoLogic is not responsible for"      -ForegroundColor Yellow
Write-Host "  data loss or hardware failure. Always back up your registry"  -ForegroundColor Yellow
Write-Host "  and data before making changes."                              -ForegroundColor Yellow
Write-Host "===============================================================" -ForegroundColor DarkYellow
Write-Host ""
$Consent = Read-Host "Type YES to accept and continue, or anything else to exit"
if ($Consent -ne "YES") {
    Write-Host "[!] User declined. Exiting safely." -ForegroundColor Red; Exit
}
Write-Host ""

Write-Host "[*] Scanning for Build 22631.3235 audio conflicts..." -ForegroundColor Yellow
$OS = Get-ComputerInfo | Select-Object WindowsProductName, OsBuildNumber
$KB = if(Get-HotFix | Where-Object { $_.HotFixID -match "KB5035853" }){"PATCHED (KB5035853)"}else{"PENDING"}
Write-Host "    > OS Build: $($OS.OsBuildNumber) ($($OS.WindowsProductName))" -ForegroundColor Gray
Write-Host "    > Moment 5: $KB" -ForegroundColor Gray
Write-Host ""

$ClassKey = "HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e96c-e325-11ce-bfc1-08002be10318}"
$Conflicts = 0
Get-ChildItem -Path $ClassKey -ErrorAction SilentlyContinue | ForEach-Object {
    $Desc = Get-ItemProperty -Path $_.PSPath | Select-Object -ExpandProperty DriverDesc -ErrorAction SilentlyContinue
    if ($Desc -match "Realtek|Intel.*Smart Sound|Senary|High Definition Audio") {
        Write-Host "    [!] Conflict Detected: $Desc" -ForegroundColor Red
        $PowerKey = "$($_.PSPath)\PowerSettings"
        if (Test-Path $PowerKey) {
            Write-Host "        PowerSettings key found — registry patch required." -ForegroundColor Yellow
        }
        $Conflicts++
    }
}

Write-Host ""
if ($Conflicts -gt 0) {
    Write-Host "###############################################################" -ForegroundColor Yellow
    Write-Host "  RESULT: $Conflicts audio driver conflict(s) detected."         -ForegroundColor Yellow
    Write-Host "  ACTION: Full remediation requires the Architect v5.5 Suite."   -ForegroundColor Cyan
    Write-Host "  PURCHASE: https://delgadologic.tech"                           -ForegroundColor Gray
    Write-Host "###############################################################" -ForegroundColor Yellow
} else {
    Write-Host "[RESULT] No critical conflicts detected." -ForegroundColor Green
}

Write-Host ""
Write-Host "Diagnostic ID: $DiagID" -ForegroundColor White
Write-Host "Support: support@delgadologic.tech" -ForegroundColor Gray
Write-Host ""
Write-Host "Press any key to exit..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
