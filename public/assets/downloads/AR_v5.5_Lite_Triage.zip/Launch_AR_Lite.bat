@echo off
:: DelgadoLogic AR-Series v5.5 Lite - One-Click Triage Launcher
:: Logic: Self-elevates, unblocks MotW, pins directory, launches Lite_AR
:: Contact: support@delgadologic.tech | https://delgadologic.tech | GitHub: Chronolapse411

>nul 2>&1 "%SYSTEMROOT%\system32\cacls.exe" "%SYSTEMROOT%\system32\config\system"
if '%errorlevel%' NEQ '0' (
    echo Requesting Administrator Privileges...
    goto UACPrompt
) else ( goto gotAdmin )

:UACPrompt
    echo Set UAC = CreateObject^("Shell.Application"^) > "%temp%\getadmin.vbs"
    echo UAC.ShellExecute "%~s0", "", "", "runas", 1 >> "%temp%\getadmin.vbs"
    "%temp%\getadmin.vbs"
    exit /B

:gotAdmin
    if exist "%temp%\getadmin.vbs" ( del "%temp%\getadmin.vbs" )
    
    :: Pin working directory to this folder
    pushd "%~dp0"
    
    echo.
    echo [*] DelgadoLogic AR-Series Lite Triage v5.5
    echo [*] Initializing Hardware Discovery...
    echo.
    
    :: MotW REMEDIATION: Clear "Mark of the Web" security block
    powershell.exe -Command "Unblock-File -Path '%~dp0Lite_AR_v5.5.ps1' -ErrorAction SilentlyContinue"
    
    powershell.exe -NoProfile -ExecutionPolicy Bypass -File "Lite_AR_v5.5.ps1"
    
    if %errorlevel% neq 0 (
        echo.
        echo [!] PowerShell encountered a termination error.
        echo [*] Contact: support@delgadologic.tech
    )
    
    pause
    popd
